﻿using Assignment_1;
using System;
using System.Collections;

namespace Assignment1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BankingSystem bank = new BankingSystem();
            bank.LoginMenu();
        }
    }
}
