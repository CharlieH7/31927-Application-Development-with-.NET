StudentID: 14247845
Full Name: Charlie Huang
2 valid logins: 
Username: guest
Password 1234
Username:charlie
Password:Char!ie777
Visual Studio Version: 2022 (Net6.0)