StudentID: 14247845
Full Name: Charlie Huang
2 valid logins: 
Username: guest
Password 1234
Username:user2
Password:321password
Visual Studio Version: 2022 (Net6.0)

1. to run the application go to Assignment2/Assignment2/bin/Debug/net6.0-windows/Assignment2.exe
2. Login credentials can be found in the same folder as above called login.txt 